<!DOCTYPE html>
<html>
<head>
	<title>Add member</title>
</head>
<body background="dumbell.jpg">
<!-- form masukkan data pelanggan-->
	<form action="insert.php" method="POST">
		<table>
			<tr>
			<td>Nama:</td>
			<td><input type="text" name="nama"></td>
		</tr>
		<tr>
			<td>Nombor Kad Pengenalan:</td>
			<td><input type="text" name="ic"></td>
			</tr>					

		</table>
		<button type="submit" name="submit">Submit</button>
	</form>
</body>
</html>