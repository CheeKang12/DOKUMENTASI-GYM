<?php
include ('config.php');
$nama=$_POST['nama'];
$ic=$_POST['ic'];
//sintax inset data ke database
$qury="INSERT INTO member values ('$nama','$ic')";

if (mysql_query($qury)) 
{
	//location selepas masukkan data
	header('Location:index.php');
}
?>