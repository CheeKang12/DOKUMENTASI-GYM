<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<style type="text/css">
</style>
<body background="dumbell.jpg">
	<center><div style="height: 250px"><h1>Selamat datang ke laman web Pusat GYM JB</h1></div></center>
	<!--FORM LOGIN-->
	<center><div>
	<form action="login.php" method="POST"><strong>Sila Login</strong>
		<p>Username:<input type="text" name="username"></p>
		<p>Password:<input type="password" name="password"></p>
		<button type="submit" name="submit">Submit</button>
	</form>
</div></center>
</body>
</html>