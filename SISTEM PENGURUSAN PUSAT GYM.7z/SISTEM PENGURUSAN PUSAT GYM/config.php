<?php
//sambungan localhost
$qry=mysql_connect('localhost','root','');
//sambungan database
mysql_select_db('gym',$qry);
?>